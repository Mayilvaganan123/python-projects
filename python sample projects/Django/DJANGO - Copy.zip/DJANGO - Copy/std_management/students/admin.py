from django.contrib import admin
from .models import Student
admin.site.register(Student)
# Register your models here.
